#!/usr/bin/env python

from serial import Serial
from serial.tools import list_ports
from time import sleep
from charlie_app.reel import Reel

REEL_CMD = 0x11  # DC1
FRAME_CMD = 0x12  # DC2


def k103_reel(s, n=1, forward=True):
    cmd = bytearray([
        FRAME_CMD,
        'F' if forward else 'R',
        n,
    ])
    s.write(cmd)
    sleep(n * 1.25 + 0.1)
    t = s.read(s.in_waiting)
    print(t)


def capture(s, n=1):
    cmd = bytearray([
        FRAME_CMD,
        '*',
        n,
    ])
    s.write(cmd)
    sleep(n * 1.25 + 0.1)
    t = s.read(s.in_waiting)
    print(t)


def put_stuff(s):
    cmd = bytearray([
        REEL_CMD,
        '!',
        'C',
    ] + [
        145,  # ts  apr 16 7pm
        98,   # ts
        182,  # ts
        92,   # ts
        'h',  # desc
        'e',  # desc
        'l',  # desc
        'l',  # desc
        'o',  # desc
        ' ',  # desc
        'r',  # desc
        'e',  # desc
        'e',  # desc
        'l',  # desc
        '!',  # desc
        0,    # desc
        0,    # desc
        0,    # desc
        0,    # desc
        0,    # desc
        0,    # desc
        0,    # desc
        0,    # desc
        0,    # desc
        84,   # len
        0,    # len
        0,    # len
        0,    # len
        2,    # curr
        0,    # curr
        0,    # curr
        0,    # curr
    ])
    s.write(cmd)
    sleep(1)
    t = s.read(s.in_waiting)
    print(t)


def get_stuff(s):
    t = s.read(s.in_waiting)
    print(t)
    cmd = bytearray([
        REEL_CMD,
        '?',
        'C',
    ])
    s.write(cmd)
    sleep(1)
    t = s.read(s.in_waiting)
    from pprint import pprint
    pprint(list(t))
    # print(t)
    x = Reel.from_bytes(t)
    print(x)


if __name__ == '__main__':
    import sys
    try:
        port = sys.argv[1]
    except IndexError:
        maybes = list(list_ports.grep('usb'))
        if len(maybes) == 0:
            sys.stderr.write(
                'missing serial port (maybe /dev/tty.usbserial-something)\n')
            sys.exit(1)
        if len(maybes) > 1:
            sys.stderr.write(
                'not sure which serial port to use. '
                'likely candidates:\n{}\n'.format(
                    '\n'.join(map(lambda m: '{}\t{}\t{}'.format(
                        m.device, m.description, m.manufacturer), maybes))))
            sys.exit(1)
        port = maybes[0].device

    s = Serial(port, 9600)

    sleep(2)
    t = s.read(s.in_waiting)
    print 't', t

    # put_stuff(s)
    # k103_reel(s, 1)

    capture(s, 4)

    get_stuff(s)

    s.close()
