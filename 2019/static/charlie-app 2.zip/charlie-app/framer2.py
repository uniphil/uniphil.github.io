import logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger('framer2')


# 64-byte max frame size for arduino buffer

# 1. MARK BYTE (0)
# 2. data


def encode(data):
    out = bytearray()
    for part in data.split(chr(0x00)):
        out.extend(chr(len(part) + 1) + part)
    return out


def decode(encoded):
    out = bytearray()
    data = iter(encoded)
    for count in data:
        for _ in range(count - 1):
            out.append(data.next())
        out.append(0x00)
    return out[:-1]


def stuff(data):
    assert len(data) <= 62, \
        'stuff data must be 62 bytes or less, found {} bytes'.format(len(data))
    body = encode(data)
    header = bytearray([0x00, len(body)])
    assert len(body) == len(data) + 1
    stuffed = header + body
    assert len(stuffed) <= 64, \
        'encoding: packet of length {} should be <= 64'.format(len(stuffed))
    return stuffed


def decoder(stream):
    packet_started = False
    packet_bytes_remaining = None
    contents = bytearray()

    for byte in stream:
        if byte == 0x00:
            if packet_started:
                logger.error('Incomplete packet. Garbage: "{}"'.format(
                    contents))
                packet_bytes_remaining = None
                contents = bytearray()
            packet_started = True
            continue

        if packet_started is False:
            logger.error('Unexpected byte before packet: "{}"'.format(byte))
            continue

        elif packet_bytes_remaining is None:
            packet_bytes_remaining = byte
            continue

        contents.append(byte)
        packet_bytes_remaining -= 1

        if packet_bytes_remaining > 0:
            continue

        yield contents
        packet_started = False
        packet_bytes_remaining = None
        contents = bytearray()


def info(something):
    from pprint import pprint
    print(len(something))
    pprint(['0x{0:02X}  {0:3d}  {0:c}'.format(c) for c in something])


if __name__ == '__main__':
    for packet in decoder(stuff('')):
        print 'packet', ['0x{:02X}'.format(b) for b in packet]
        info(decode(packet))

    # info(stuff(x[0]))
