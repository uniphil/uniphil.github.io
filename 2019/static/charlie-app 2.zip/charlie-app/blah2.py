#!/usr/bin/env python

import logging
from serial import Serial
from serial.tools import list_ports
from serial.threaded import Protocol, ReaderThread
from time import sleep

FLAG_BYTE = chr(0x7E)
CONTROL_ESCAPE = chr(0x7D)
FLAGGED_REPLACE = chr(0x5E)
CONTROLLED_REPLACE = chr(0x5D)
CONTROL_RESTORE = chr(0x20)

CMD_ECHO = chr(0x40)
TX_LOG_FRAMER = chr(0x80)
TX_LOG_USER = chr(0x81)

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger('framer')


class UnexpectedFlagError(ValueError):
    """flag should not appear here"""


class Frame():
    def __init__(self, command, data):
        self.command = command
        self.data = data

    def get_stuffed(self):
        output = bytearray()
        for byte in self.data:
            if byte == FLAG_BYTE:
                output.extend([CONTROL_ESCAPE, FLAGGED_REPLACE])
            elif byte == CONTROL_ESCAPE:
                output.extend([CONTROL_ESCAPE, CONTROLLED_REPLACE])
            else:
                output.append(byte)
        header = bytearray([FLAG_BYTE, self.command, len(output)])
        return header + output

    @classmethod
    def unstuff(cls, command, bytes):
        data = bytearray()
        byte_iter = iter(bytes)
        for input_char in byte_iter:
            if input_char == FLAG_BYTE:
                raise UnexpectedFlagError('{}'.format(data))
            elif input_char == CONTROL_ESCAPE:
                data.append(byte_iter.next() ^ CONTROL_RESTORE)
            else:
                data.append(input_char)
        return cls(command, data)

    def __repr__(self):
        return '<Frame({:02X}: {})>'.format(ord(self.command), repr(self.data))


class Framer(Protocol):

    def __init__(self):
        self.transport = None
        self.frame_started = False
        self.command = None
        self.data_length = None
        self.data_buffer = bytearray()

    def connection_made(self, transport):
        self.transport = transport

    def connection_lost(self, exc):
        self.transport = None
        super(Framer, self).connection_lost(exc)

    def data_received(self, data):
        data = bytearray(data)

        if not self.frame_started:
            pre_garbage, sep, data = data.partition(FLAG_BYTE)
            if len(pre_garbage) > 0:
                self.handle_garbage(pre_garbage)
            if len(sep) == 0:
                return
            self.frame_started = True

        if self.command is None:
            try:
                self.command = chr(data.pop(0))
            except IndexError:
                return

        if self.data_length is None:
            try:
                self.data_length = data.pop(0)
            except IndexError:
                return

        bytes_remaining = self.data_length - len(self.data_buffer)
        self.data_buffer.extend(data[:bytes_remaining])
        if len(self.data_buffer) < self.data_length:
            return

        self.handle_frame(Frame.unstuff(self.command, self.data_buffer))
        self.frame_started = False
        self.command = None
        self.data_length = None
        self.data_buffer = bytearray()

        self.data_received(data[bytes_remaining:])

    def handle_frame(self, frame):
        if frame.command == TX_LOG_FRAMER:
            logger.warn('framer: %s', frame.data)
        elif frame.command == TX_LOG_USER:
            logger.info('user: %s', frame.data)
        else:
            logger.warn('unhandled: %s', frame)

    def handle_garbage(self, garbage):
        logger.warn(
            'out-of-frame:\n%s', '\n'.join(
                ['{0:02X} {1}'.format(x, chr(x)) for x in garbage]))

    def send(self, command, data):
        logger.debug('sending command: "%s"...', command)
        frame = Frame(command, data)
        bytes = frame.get_stuffed()
        self.transport.write(bytes)


if __name__ == '__main__':
    import sys
    try:
        port = sys.argv[1]
    except IndexError:
        maybes = list(list_ports.grep('usb'))
        if len(maybes) == 0:
            sys.stderr.write(
                'missing serial port (maybe /dev/tty.usbserial-something)\n')
            sys.exit(1)
        if len(maybes) > 1:
            sys.stderr.write(
                'not sure which serial port to use. '
                'likely candidates:\n{}\n'.format(
                    '\n'.join(map(lambda m: '{}\t{}\t{}'.format(
                        m.device, m.description, m.manufacturer), maybes))))
            sys.exit(1)
        port = maybes[0].device

    s = Serial(port, 9600)

    with ReaderThread(s, Framer) as device:
        while True:
            sleep(2)
            device.send(CMD_ECHO, 'hellooooo')

    sleep(0.5)

    # pprint(['0x{0:02X}  {0:3d}  {0:c}'.format(ord(c)) for c in t])

    s.close()
